Welcome to the warp zone!

# TensorFlow Federated

These docs are available here: https://github.com/tensorflow/federated/tree/master/docs
