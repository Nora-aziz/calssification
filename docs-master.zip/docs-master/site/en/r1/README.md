# TensorFlow 1.x

This archive of the TensorFlow 1.x docs is in *maintenance mode* only.

For docs contributors, please update the source files in `site/en/` and read the
[TensorFlow docs contributor guide](https://www.tensorflow.org/community/contribute/docs).

For community translations, read the instructions in `site/<lang>/README.md`.
