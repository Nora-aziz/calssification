<?cs each:pkg=docs.packages ?><?cs var: pkg.name ?>
<?cs /each ?>
