# API reference

Create a `build_docs.py` script using the `api_generator` API:
https://github.com/tensorflow/docs/tree/master/tools/tensorflow_docs/api_generator
